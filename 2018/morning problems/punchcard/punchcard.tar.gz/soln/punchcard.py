import sys

for line in sys.stdin:
    line = line.strip() # gets rid of trailing \n

    if not line:
        # the line was empty, what does the problem
        # statement ask you to do?
        pass
    else:
        # the line is not empty, it corresponds
        # to some ascii character
