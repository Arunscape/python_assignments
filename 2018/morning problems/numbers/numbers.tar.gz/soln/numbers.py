# NOTE: you should figure out how to read the input for this problem yourself
# as it is good practice for real morning problems.

# read number of friends

# for each friend, read their numbers..

# read the index of friend whose numbers should be printed

# print the favourite numbers of the selected friend
