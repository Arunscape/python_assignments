n = int(input())

for i in range(n):
    x, y = input().split()
    # now x is the binary encoding for sequence of word y
    # how do you want to store this?

code = input()

# decode sentence
