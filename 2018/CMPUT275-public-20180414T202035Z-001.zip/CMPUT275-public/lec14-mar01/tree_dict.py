import bstviz
import random

class BSTNode:
    """
    Binary search tree node, storing key, item, left, right.
    """

    def __init__(self, key, item):
        """
        Initializes as a leaf node (no children).
        """
        self.key = key
        self.item = item
        self.left = self.right = None

class TreeDict:
    def __init__(self):
        """
        Initializes as an empty tree.
        """
        self.root = None
        self.len = 0

    def _find(self, key):
        """
        Find the node with the given key, None if the key is not found.
        Also returns the parent of this node in the search.
        """
        node, parent = self.root, None

        while node is not None and key != node.key:
            parent = node
            if key < node.key:
                node = node.left
            else:
                node = node.right

        return node, parent

    def update(self, key,item):
        """
        Updates the dictionary to store the item at the given key.
        If the key was not already present, it is added.
        """

        # special case, tree is empty
        if self.root is None:
            self.root = BSTNode(key, item)
            self.len += 1
            return

        node, parent = self._find(key)

        if node is not None:
            # key found, just replace the item
            node.item = item
        elif key < parent.key:
            parent.left = BSTNode(key, item)
            self.len += 1
        else:
            parent.right = BSTNode(key, item)
            self.len += 1

    def get(self, key):
        """
        Same as a Python dictionary get. Returns the item if the
        key is present, None otherwise.
        """

        node, _ = self._find(key)

        if node is None:
            return None
        else:
            return node.item

    def popitem(self, key):
        """
        Remove the entry with the given key.
        Raises a key error if not found.
        """

        node, parent = self._find(key)

        if node is None:
            raise KeyError(key)

        self.len -= 1

        if node.left is None:
            # just update the appropriate child pointer of
            # the parent to point to node.right
            if parent is None:
                self.root = node.right
            elif key < parent.key:
                parent.left = node.right
            else:
                parent.right = node.right
        else:
            # we won't actually remove this node, we will
            # find the node with the maximum key in the subtree
            # under node.left, move the key/item here, and delete that node

            max_node, max_parent = node.left, node
            while max_node.right is not None:
                max_node, max_parent = max_node.right, max_node

            node.key, node.item = max_node.key, max_node.item

            if max_node == max_parent.right:
                max_parent.right = max_node.left
            else:
                max_parent.left = max_node.left

    def items(self):
        """
        Returns a list of the (key, item) pairs in
        sorted order of their keys.
        """

        outlist = []

        def recurse(node):
            if node is None:
                return
            recurse(node.left)
            outlist.append((node.key, node.item))
            recurse(node.right)

        recurse(self.root)

        return outlist

    def __str__(self):
        return str(self.items())

    def __len__(self):
        return self.len

    def __contains__(self, key):
        node, _ = self._find(key)
        return node is not None

    def __getitem__(self, key):
        node, _ = self._find(key)
        if node is None:
            raise KeyError(key)
        else:
            return node.item

    def __setitem__(self, key, item):
        self.update(key, item)


if __name__ == "__main__":
    tree = TreeDict()

    # insert up to 25 random keys, only works once you have the
    # update method working
    for i in range(25):
       tree.update(random.randrange(100), random.choice("abcdefg"))

    bstviz.bstviz(tree).render(view=True)

    # uncomment the rest below once you have popitem working

    while len(tree):
        val = int(input("Enter a key to remove: "))
        tree.popitem(val)
        bstviz.bstviz(tree).render(view=True)
