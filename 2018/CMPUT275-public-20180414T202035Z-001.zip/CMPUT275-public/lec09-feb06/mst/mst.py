from union_find import UnionFind

def kruskal(vertices, edges):
    """
    Implementation of Kruskal's algorithm for
    computing a minimum spanning tree.

    vertices: set of vertices of the graph
    edges: dictionary mapping undireced edges
      represented as pairs to their cost
      Example: {(1,3):2, (1,2):5}
      The edge (1,3) has cost 2 and the edge (1,2)
      has cost 5.

    Returns the set of set of edges forming the
    spanning tree and the cost of this tree:
      return cost, edges

    >>> vertices = {1, 2, 3}
    >>> edges = {(1, 2):1, (1, 3):3, (2, 3):2}
    >>> cost, tree = kruskal(vertices, edges)
    >>> cost
    3
    >>> tree == {(1,2), (2,3)}
    True

    TRY ADDING MORE TESTS
    """

    # initialize data structures
    uf = UnionFind(vertices)
    tree = set()
    cost = 0

    # get a list of edges sorted by cost
    sorted_edges = list(edges.items())
    sorted_edges.sort(key = lambda x : x[1])

    # for each edge in sorted order
    for (u, v), c in sorted_edges:
        # if the endpoints are not yet connected
        if uf.find(u) != uf.find(v):
            # keep the edge
            uf.union(u, v)
            tree.add((u, v))
            cost += c

    return cost, tree

if __name__ == "__main__":
    import doctest
    doctest.testmod()
