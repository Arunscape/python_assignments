from collections import Counter
from binary_heap import BinaryHeap

class TreeLeaf:
    """
    Leaf node of a Huffman tree. Stores the byte or EOF.
    We represent EOF with None, a byte with an int.
    """

    def __init__(self, value):
        self.value = value

class TreeBranch:
    """
    Simple representation of an internal node in a Huffman tree.
    Just stores the two children.
    """

    def __init__(self, left, right):
        self.left = left
        self.right = right

def make_tree(freq_table):
    """
    Constructs and returns the Huffman tree from the given frequency
    table. Also includes an EOF leaf (a leaf storing None).
    """

    trees = BinaryHeap()
    for (symbol, frequency) in freq_table.items():
        trees.insert(TreeLeaf(symbol), frequency)
    trees.insert(TreeLeaf(None), 1)

    while len(trees) > 1:
        ltree, lfreq = trees.popmin()
        rtree, rfreq = trees.popmin()

        new_tree = TreeBranch(ltree, rtree)
        trees.insert(new_tree, lfreq + rfreq)

    final_tree, _ = trees.popmin()
    return final_tree

def make_encoding_table(huffman_tree):
    """
    Given a Huffman tree, will make the encoding table mapping each
    byte (leaf node, including EOF)
    to its corresponding bit sequence in the tree.
    """
    table = {} # empty dictionary

    def recurse(tree, path):
        """
        Traces out all paths in the tree to the leaves and adds
        each corresponding leaf value and its associated
        path to the table.
        """

        if isinstance(tree, TreeLeaf):
            # even works if this is the EOF leaf node,
            # will store table[None] = path
            table[tree.value] = path
        elif isinstance(tree, TreeBranch):
            # the comma tells Python this should be a
            # tuple of length 1
            recurse(tree.left, path+(False,))
            recurse(tree.right, path+(True,))
        else:
            raise TypeError("{} is not a tree type".format(type(tree)))

    recurse(huffman_tree, ())

    return table


def make_freq_table(stream):
    """
    Given an input stream, will construct a frequency table
    (i.e. mapping of each byte to the number of times it occurs
    in the stream).
    """

    freqs = Counter()
    buffer = bytearray(512)

    while True:
        count = stream.readinto(buffer)
        freqs.update(buffer[:count])
        if count < len(buffer):
            break
    return freqs

if __name__ == "__main__":
    # demonstration of how to use make_freq_table to count
    # the bytes of simple.txt
    # assumes simple.txt is in the same directory
    input_stream = open("small.txt", "rb")
    freqs = make_freq_table(input_stream)
    print(freqs)
    print()

    huff_tree = make_tree(freqs)

    print(huff_tree)
    print()

    enc_table = make_encoding_table(huff_tree)

    print(enc_table)
